/*
 * Licensed to the Apache Software Foundation (ASF) under one
 * or more contributor license agreements.  See the NOTICE file
 * distributed with this work for additional information
 * regarding copyright ownership.  The ASF licenses this file
 * to you under the Apache License, Version 2.0 (the
 * "License"); you may not use this file except in compliance
 * with the License.  You may obtain a copy of the License at
 *
 *  http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing,
 * software distributed under the License is distributed on an
 * "AS IS" BASIS, WITHOUT WARRANTIES OR CONDITIONS OF ANY
 * KIND, either express or implied.  See the License for the
 * specific language governing permissions and limitations
 * under the License.
 */
package org.apache.karaf.examples.deployer;

import org.apache.felix.fileinstall.ArtifactInstaller;
import org.apache.felix.fileinstall.ArtifactListener;
import org.osgi.service.component.annotations.Component;

import java.io.File;

@Component(service = { ArtifactInstaller.class, ArtifactListener.class })
public class ExampleDeployer implements ArtifactInstaller {


    @Override
    public void install(File file) throws Exception {
        System.out.println("Example deployer should install " + file.getName());
    }

    @Override
    public void update(File file) throws Exception {
        System.out.println("Example deployer should update " + file.getName());
    }

    @Override
    public void uninstall(File file) throws Exception {
        System.out.println("Example deployer should uninstall " + file.getName());
    }

    @Override
    public boolean canHandle(File file) {
        // here we check if the deployer should handle the file (true) or not (false)
        // for the example, we take any file
        return true;
    }
}
